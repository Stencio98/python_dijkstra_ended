import threading
import heapq
#import numpy as np
import time #time.sleep
import itertools
import queue

#from tkinter import *
#from tkinter import ttk

hoFinito = 0
esci = 0
tempo = 0
TIME = 0

def getTIME():
    return TIME

def start(start, end):
    #start = input("start: ")
    #end = input("end: ")

    q = queue.Queue()

    elenco1 = []
    elenco1.append(start)
    elenco1.append(end)

    with open("app_folder/words.italian.txt", "r") as f:
        for line in f:
            word = line.strip()
            elenco1.append(word)
        f.close()

    elenco1 = list(set(elenco1))  # toglie eventuali ripetizioni delle parole
    elenco = {word: None for word in elenco1}

    t1 = threading.Thread(target=dijkstra, args=(start, end, R1, R2, R3, R4, R3333, q, elenco))
    t2 = threading.Thread(target=dijkstra, args=(end, start, R1, R2, R3, R4, R3333, q, elenco))
    t3 = threading.Thread(target=SLEEP)
    t1.start()
    t2.start()
    t3.start()
    t1.join()
    t2.join()
    t3.join()
    RESULT = q.get()
    """se ho 'barato' devo fare il reverse"""
    if RESULT != []:
        if RESULT[0] != start:
            print("reversing")
            RESULT.reverse()
    print("---q.get()---")
    print(RESULT)
    print("---q.get()---")
    return RESULT


def SLEEP(): #timer per l'esecuzione
    global tempo
    global TIME
    TIME = 0
    print("secondi trascorsi:")
    print(0, end='\r')
    while TIME < 180:
        time.sleep(1)
        if hoFinito == 1:
        	exit(0)
        print(TIME, end='\r')
        TIME = TIME + 1
    tempo = 1
    exit(0)

"""implementa l'algoritmo di ricerca di D."""
def dijkstra(start, end, R1, R2, R3, R4, R3333, q, e):
        """var locali condivise tra i thread"""
        global hoFinito
        global tempo
        global esci

        """setta una lista di elementi già visitati"""
        visited = set()
        parent = {start: None}
        distances = {start: 0}
        heap = [(0, start)]
        while heap:
            """esce se una funzione ha concluso, oppure il tempo è scaduto"""
            if esci == 1 or tempo == 1:
                #print("dk: exit(0)")
                #print("esco in while heap and tempo")
                exit(0)
            (distance, current) = heapq.heappop(heap)
            if current in visited:
                continue
            visited.add(current)
            if current == end:
                path = [end]
                while parent[current] is not None:
                    path.append(parent[current])
                    current = parent[current]
                hoFinito = 1
                q.put(path[::-1])
                esci = 1
                #return path[::-1]
            neighbors = R1(current, e) + R2(current, e) + R3(current, e) + R4(current, e) + R3333(current, e)
            for neighbor in neighbors:
                if esci == 1 or tempo == 1:
                    #print("dk: exit(0)")
                    #print("esco in neighbor in neighbors")
                    exit(0)
                new_distance = distance + 1# la funzione generate_rXXX non fornisce informazioni sul costo
                if neighbor not in visited and (neighbor not in distances or new_distance < distances[neighbor]):
                    distances[neighbor] = new_distance
                    parent[neighbor] = current
                    heapq.heappush(heap, (new_distance, neighbor))
        #return []
        q.put([])
        esci = 1


def R3(word, elenco): #regola 3
    #print("called R3")
    result = []
    for i in range(len(word)):
        for j in range(26):
            new_word = word[:i] + chr(97 + j) + word[i+1:]
            if new_word in elenco:
                result.append(new_word)
    #print("result R3")
    #print(result)
    return result

def R3333(word, elenco): #var regola 3
    result = []
    for j in range(26):
        for i in range(len(word)):
            new_word = word[:i] + chr(97 + j) + word[i+1:]
            if new_word in elenco:
                result.append(new_word)
                break
    return result

def R2(word, elenco): #regola 2
    #print("called R2")
    result = []
    word_perms = [''.join(p) for p in itertools.permutations(word)]
    word_perms = {word: None for word in word_perms}
    for perm in word_perms:
        if perm in elenco:
            result.append(perm)
    result = list(set(result))#toglie eventuali doppioni
    #print("result R2")
    #print(result)
    return result

def R1(word, elenco): #regola 1
    result = []
    for i in range(len(word) + 1):
        for j in range(26):
            new_word = word[:i] + chr(97 + j) + word[i:]
            if new_word in elenco:
                result.append(new_word)
    #print("result R1")
    #print(result)
    return result

def R4(word, elenco): #regola 1
    #print("called R4")
    result = []
    for i in range(len(word)):
        #new_word = word[::i] - word[i]
        new_word = word[:i] + word[i+1:]
        if new_word in elenco:
            result.append(new_word)
    #print("result R4")
    #print(result)
    return result


######################################








