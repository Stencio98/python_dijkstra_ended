#sudo apt-get install python3-pil python3-pil.imagetk
#vanno installati anche tkinter, networkx e matplotlib
import tkinter as tk
import functions
import networkx as nx
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import subprocess

#sfondo bianco
#bottoni blu con scritte bianche
#word 1 e 2 dentro riquadri

def visione_dizionario():
    subprocess.run(["./app_folder/dizionario.sh"])
    
def restart_program():
    root.destroy()
    subprocess.Popen(["./start.sh"])
    
        
def show_graph(elements):
    word1_entry.destroy()
    word1_label.destroy()
    word2_entry.destroy()
    word2_label.destroy()
    process_button.destroy()
    w1 = tk.Label(root, text="seconds needed:", font = "Helvetica 12 bold italic")
    w1.pack(pady=10)
    w1.configure(bg='#2A52BE', fg='light blue')
    w2 = tk.Label(root, text=functions.getTIME(), font = "Helvetica 12 bold italic")
    w2.pack()
    w2.configure(bg='#2A52BE', fg='light blue')

    G = nx.DiGraph()
    G.add_nodes_from(elements)
    for i in range(len(elements) - 1):
        G.add_edge(elements[i], elements[i + 1])
    pos = nx.spring_layout(G)
    font_color='white'
    nx.draw(G, pos, with_labels=True, arrows=True, node_color='#007FFF', font_family='Arial', edge_color='#ED7465', arrowstyle='fancy', node_size=2000, width=2, font_color=font_color)
    fig = plt.gcf()
    #fig.set_facecolor('#FFFFFF')
    fig.set_facecolor('#2A52BE')
    fig.set_size_inches(8, 8)
    plt.tight_layout()
    plt.show()


def entry_click():
    return 0

root = tk.Tk()
root.title("Word Processor")    
#root.geometry("600x400")
root.configure(bg='#2A52BE')

root.resizable(False, False)
word1_label = tk.Label(root, text="Word 1:", font = "Helvetica 12 bold italic", fg='light blue')
word1_label.pack()
word1_label.configure(bg='#2A52BE')

word1_entry = tk.Entry(root)
word1_entry.pack(pady=10)
word1_entry.configure(relief='flat', bg='#007FFF', highlightbackground='#007FFF')

word2_label = tk.Label(root, text="Word 2:", font = "Helvetica 12 bold italic", fg='light blue')
word2_label.pack()
word2_label.configure(bg='#2A52BE')

word2_entry = tk.Entry(root)
word2_entry.pack(pady=10)
word2_entry.configure(relief='flat', bg='#007FFF', highlightbackground='#007FFF')
#bottone ricerca parole
process_button = tk.Button(root, text="FIND PATH", command=lambda: show_graph(functions.start(word1_entry.get(), word2_entry.get())))
process_button.pack(pady=10)
process_button.configure(bg='#2A52BE', fg='#ED7465', activeforeground='light green', relief='flat', borderwidth=0)
process_button.configure(activebackground="#2A52BE", font = "Helvetica 12 bold italic", highlightbackground='#2A52BE')

#creazione bottone per riavvio del programma
continue_button = tk.Button(root, text = "RESTART", command=lambda: restart_program())
continue_button.pack(pady=10)
continue_button.configure(fg='#ED7465', relief='flat', highlightbackground='#2A52BE')
continue_button.configure(borderwidth=0)
continue_button.configure(bg='#2A52BE', font = "Helvetica 12 bold italic")
continue_button.configure(activebackground='#2A52BE', activeforeground='light green')

#bottone visione dizionario
dizionario_button = tk.Button(root, text="DICTIONARY", command=lambda: visione_dizionario())
dizionario_button.pack(pady=10)
dizionario_button.configure(bg='#2A52BE', font = "Helvetica 12 bold italic", relief='flat', highlightbackground='#2A52BE')
dizionario_button.configure(activebackground='#2A52BE', fg='#ED7465', activeforeground='light blue')
dizionario_button.configure(borderwidth=0)

#creazione bottone uscita programma
exit_button = tk.Button(root, text = "EXIT PROGRAM", command=lambda: root.destroy())
exit_button.pack(pady=10, padx=100)
exit_button.configure(bg="#2A52BE", font = "Helvetica 12 bold italic", highlightbackground='#2A52BE', borderwidth=0)
exit_button.configure(activebackground="#2A52BE", fg='#ED7465', activeforeground='orange', relief='flat')
root.mainloop()
