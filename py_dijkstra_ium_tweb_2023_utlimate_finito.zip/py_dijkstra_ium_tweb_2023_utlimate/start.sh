#!/bin/sh
python3 app_folder/gui.py;
