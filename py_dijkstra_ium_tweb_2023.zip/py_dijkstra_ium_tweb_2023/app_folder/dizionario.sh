#!/bin/sh
open app_folder/words.italian.txt;