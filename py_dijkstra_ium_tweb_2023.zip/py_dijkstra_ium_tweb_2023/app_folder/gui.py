#sudo apt-get install python3-pil python3-pil.imagetk
#vanno installati anche tkinter, networkx e matplotlib
import tkinter as tk
import functions
import networkx as nx
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import subprocess


def visione_dizionario():
    subprocess.run(["./app_folder/dizionario.sh"])
    
def restart_program():
    root.destroy()
    subprocess.Popen(["./start.sh"])
    
        
def show_graph(elements):
    process_button.destroy()
    w1 = tk.Label(root, text="seconds needed:")
    w1.pack(pady=10)
    w1.configure(bg='light blue')
    w2 = tk.Label(root, text=functions.getTIME())
    w2.pack(pady=10)
    w2.configure(bg='#BDECB6')

    G = nx.DiGraph()
    G.add_nodes_from(elements)
    for i in range(len(elements) - 1):
        G.add_edge(elements[i], elements[i + 1])
    pos = nx.spring_layout(G)
    nx.draw(G, pos, with_labels=True, arrows=True, node_color='#FFC0CB', font_family='Arial', edge_color='#000000', arrowstyle='fancy', node_size=800, width=2)
    fig = plt.gcf()
    #fig.set_facecolor('#FFFFFF')
    fig.set_facecolor('#BDECB6')
    fig.set_size_inches(8, 8)
    plt.tight_layout()
    plt.show()



root = tk.Tk()
root.title("Word Processor")
root.geometry("600x400")
root.configure(bg='light blue')

root.resizable(False, False)
word1_label = tk.Label(root, text="Word 1:")
word1_label.pack(pady=10)
word1_label.configure(bg='light blue')

word1_entry = tk.Entry(root)
word1_entry.pack(pady=10)

word2_label = tk.Label(root, text="Word 2:")
word2_label.pack(pady=10)
word2_label.configure(bg='light blue')

word2_entry = tk.Entry(root)
word2_entry.pack(pady=10)

#bottone ricerca parole
process_button = tk.Button(root, text="Process", command=lambda: show_graph(functions.start(word1_entry.get(), word2_entry.get())))
process_button.pack(pady=10)
process_button.configure(bg='light gray')
process_button.configure(activebackground="light green")

#creazione bottone per riavvio del programma
continue_button = tk.Button(root, text = "restart", command=lambda: restart_program())
continue_button.pack(pady=10)
continue_button.configure(bg='light gray')
continue_button.configure(activebackground='light green')

#bottone visione dizionario
dizionario_button = tk.Button(root, text="visiona il dizionario", command=lambda: visione_dizionario())
dizionario_button.pack(pady=10)
dizionario_button.configure(bg='light gray')
dizionario_button.configure(activebackground='light yellow')

#creazione bottone uscita programma
exit_button = tk.Button(root, text = "exit", command=lambda: root.destroy())
exit_button.pack(pady=10)
exit_button.configure(bg="gray")
exit_button.configure(activebackground="red")

root.mainloop()
